from django.shortcuts import render
import pyodbc 
import pandas as pd
import plotly.express as px

# Create your views here.
def indexT(request):
    return render(request,'index.html')
def analytics(request):
    return render(request,'Analytics.html')
def add(request):
    return render(request,'addAddress.html')
def doc(request):
    return render(request, 'Doc.html')
conn = pyodbc.connect("Driver={SQL Server};"
                      "Server=YDATLWCRM0002;"
                      "Database=DB_DW_CRM;"
                      "Trusted_Connection=yes;")
country="SELECT [Country_EN],[Account_Name],[Visit address] FROM [DB_DW_CRM].[dbo].[DWH_DIM_ACCOUNT]"
country = pd.read_sql_query(country, conn)
df=country[country['Account_Name'].str.contains('test')==False]
df=df[df['Account_Name'].str.contains('Test')==False]
df=df[df['Visit address'].str.contains('test')==False]
df=df.replace({'':None})
def missingness(request):
    df1=pd.DataFrame()
    df1['Present']=list(df.count())
    df1['Present_Percent']=list(df.count()/len(df)*100)
    df1['Missing']=list(df.isna().sum())
    df1['Missing_Percent']=list(df.isna().mean())
    df1['columns']=list(df.columns)
    # Create the Plotly figure
    fig = px.histogram(df1, x='columns', y=['Missing', 'Present'], color_discrete_sequence=['#003C30', '#55A185'], width=520)
    fig.update_layout(
           title_text='Missingness Bar Chart',  # title of plot
           xaxis_title_text='',  # xaxis label
           yaxis_title_text='Count'
       )
    fig.update_traces(opacity=0.85)
    fig.update_xaxes(tickangle=-45)
    # Convert the plot to JSON
    plot_json = fig.to_json()
    # Pass the plot JSON to the template
    context = {'plot_json': plot_json}
    return render(request, 'Analytics.html', context)