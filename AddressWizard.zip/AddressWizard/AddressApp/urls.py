from django.contrib import admin
from django.contrib import admin
from django.urls import include, path
from AddressApp import views
urlpatterns=[
    path('',views.indexT,name='index'),
    path('Analytics/',views.analytics,name='Analytics'),
    path('Documentation/',views.doc,name='Doc'),
    path('AddAddress/',views.add,name='addAddress'),
]
