from email.policy import default
from django.shortcuts import render
import json
import pyodbc
import pandas as pd
import plotly.express as px
import plotly.offline as pio
import plotly
import plotly.graph_objects as go
from django.http import JsonResponse
import numpy as np
from AddressApp.models import Account

 

# Create your views here.
def indexT(request):
    return render(request,'index.html')

def analytics(request):
    return render(request,'Analytics.html')

def add(request):
    return render(request,'addAddress.html')

def doc(request):
    return render(request, 'Doc.html')

conn = pyodbc.connect("Driver={SQL Server};"
                      "Server=YDATLWCRM0002;"
                      "Database=DB_DW_CRM;"
                      "Trusted_Connection=yes;")

country="SELECT [Country_EN],[Account_Name],[Visit address] FROM [DB_DW_CRM].[dbo].[DWH_DIM_ACCOUNT]"
country = pd.read_sql_query(country, conn)
df=country[country['Account_Name'].str.contains('test')==False]
df=df[df['Account_Name'].str.contains('Test')==False]
df=df[df['Visit address'].str.contains('test')==False]
df=df.replace({'':None})

 

#INDEX
def showlist(request):
    accounts = Account.objects.all()
    return render(request, "home.html",{"showcity":results})






def get_companies_with_addresses(df):
   # Assuming your dataframe is named df and your columns are 'companyname' and 'address'
    # Drop NaN values in the 'address' column
    df = df.dropna(subset=['Visit address'])
    # Get the list of company names
    company_names = df['Account_Name'].tolist()
    return company_names

companies_with_addresses = get_companies_with_addresses(df)

def get_companies_with_addresses(df):
   # Assuming your dataframe is named df and your columns are 'companyname', 'address', and 'country'
    # Drop NaN values in the 'address' column
    df = df.dropna(subset=['Visit address'])
    # Get the dataframe with company names, addresses, and country
    df_with_addresses = df[['Account_Name', 'Visit address', 'Country_EN']]
    return df_with_addresses

df_with_addresses = get_companies_with_addresses(df)
#ANALYTICS

def analytics(request):
    df1=pd.DataFrame()
    df1['Present']=list(df.count())
    df1['Present_Percent']=list(df.count()/len(df)*100)
    df1['Missing']=list(df.isna().sum())
    df1['Missing_Percent']=list(df.isna().mean())
    df1['columns']=list(df.columns)
    data = {
        'columns': df1['columns'].tolist(),
        'missing': df1['Missing'].tolist(),
        'present': df1['Present'].tolist(),
    }
    return render(request, 'Analytics.html', {'data': json.dumps(data)})

df2=df.dropna()

unique_countries=df2['Country_EN'].unique()

 

def top_5_countries(data):
    cnt={}
    for country in list(data['Country_EN'].unique()):
        try:
           cnt[country]=data['Country_EN'].value_counts()[country]
        except:
            pass
    sorted_cnt=dict(sorted(cnt.items(), key=lambda item:item[1],reverse=True))
    top_5=[]
    i=0
    count=0
    while i<5:
        top_5.append(list(sorted_cnt.items())[i])
        i+=1
    for j in range(5,len(sorted_cnt)):
        count+=list(sorted_cnt.values())[j]
    top_5=dict(top_5)
    top_5=dict(sorted(top_5.items(), key=lambda item:item[1],reverse=False))
    items = list(top_5.items())
    items.insert(0,('Other',count))
    top_5=dict(items)
    return top_5

 

#PIE CHART ADDRESS TYPES: